/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bingocard;

/**
 *
 * @author Student
 */
import java.util.Scanner;
import java.util.Random;

public class BingoGame {


   public static int totalGamesWon = 0;
   public static BingoCard myCard;


   public static void main(String[] args){
      
       String playAgain = "yes";
       Scanner keyboard = new Scanner(System.in);
           do
           {
              myCard = new BingoCard();
              System.out.println("\nHere is your new BINGO Card...Good Luck! ");
              System.out.println(myCard);
              playGame();
              determineWinner();
              System.out.println("Would you like to play again? ");
              playAgain = keyboard.nextLine();
           } while (playAgain.equalsIgnoreCase("yes"));
      
         
       System.out.println("You won " + totalGamesWon + " Bingo games.");            
   }
  
   public static void playGame()
   {
       int randomNumber = 0;
       Random myRan = new Random();
      
       for (int i = 0; i < 50; i++)
       {
           randomNumber = myRan.nextInt(1, 76);
           myCard.checkBingo(randomNumber);           
       }
   }
  
   /**
    *
    */
   public static void determineWinner()
   {
       boolean isWinner = myCard.gotBingo();
       if ((isWinner) == true)
       {
           System.out.println("BINGO!");
           totalGamesWon++;
       } else{
           System.out.println("You didn't win");
       }
      
       System.out.println("Here's your game results: ");
       System.out.println(myCard);
      
       System.out.println("So far, you have won " + totalGamesWon + ". ");
       System.out.println("***************************");
   }
 
  
}



