/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bingocard;

/**
 *
 * @author Student
 */
import java.util.Random;
public class BingoCard {
  
   private int[][] bingoCardArray = new int[5][5];
  
   /**
    *
    */
   public BingoCard()
   {
       Random myRan = new Random();
      
      for (int col = 0; col < 5; col++)
       {
           for (int row = 0; row < 5; row++)
           {
              int ranNum;
           if (col == 0)
              {
                 do{
                       ranNum = myRan.nextInt(15) + 1;   //  myRan.nextInt(high - low + 1) + low
                   } while (checkForDuplicates(col, ranNum) == true);
                 bingoCardArray[row][col] = ranNum;
         
              }
              else if (col == 1)
              {
                  do
                  {
                      ranNum = myRan.nextInt(15) + 16;  //random Number between 16 & 30
                  } while (checkForDuplicates(col, ranNum) == true);
                   bingoCardArray[row][col] = ranNum;
              }
              else if(col == 2)
              {
                  do{
                      ranNum = myRan.nextInt(15) + 31;
                  } while(checkForDuplicates(col,ranNum) == true);
                  bingoCardArray[row][col] = ranNum;
               }
                  else if(col == 3)
                  {
                      do{
                          ranNum = myRan.nextInt(15) + 46;
                      } while(checkForDuplicates(col, ranNum) == true);
                       bingoCardArray[row][col] = ranNum;
                  }
                  else if(col == 4)
                  {
                      do{
                          ranNum = myRan.nextInt(15) + 61;
                      } while(checkForDuplicates(col, ranNum) == true);
                      bingoCardArray[row][col] = ranNum;
                  }
                     
           }
       }
   }
   public boolean checkForDuplicates(int col, int ranNum)
   {
       //check all the rows in the provided col and see if any
       //values in the cells match the ranNum.  If they do, return true;
       //if none of the values in the cells in the provided col match ranNum
       //return false.
       boolean checkForDup = false;
       for(int row = 0; row < 5; row++)
       {
           if(bingoCardArray[row][col] == ranNum)
           {
               checkForDup = true;
           }
       }
       return checkForDup;
   }
  
   /**
    * Post-Condition:  For every match in 2D array with aNum the number 0 will replace the match
    * @param aNum
    */
   public void checkBingo(int aNum)
   {
       //Receive num, and check to see if it exists anywhere in 2-D array.
       //If it finds it, a 0 will be put in the number’s place


       for(int row = 0; row < 5; row++)
       {
           for(int col = 0; col < 5; col++)
           {
               if(bingoCardArray[row][col] == aNum)
               {
                   bingoCardArray[row][col] = 0;
               }
           }
       }
   }
  
   /**
    * Pre-Condition:  The entire 2-D array is fully populated with numbers &
    *                 we have already played BINGO 50 times by calling checkBingo 50 times.
    * @return
    */
   public boolean gotBingo()
   {
       //i. Loops to check every column, to see if it finds 5 consecutive 0’s
       //ii. Loops to check every row, to see if it finds 5 consecutive 0’s
       //iii. Loops to check the 2 diagonals, to see if it finds 5 consecutive 0’s
       //iv. If any of these loops find 5 zeroes, the method will return TRUE;
       //otherwise, the method will return FALSE


       int count;
       //Check rows


       boolean gotbingo = false;


       for(int row = 0; row < 5; row++)
       {
           count = 0;
           for(int col = 0; col < 5; col++)
           {
               if(bingoCardArray[row][col] == 0)
               {
                   count++;
                  
               }
              
           }
           if(count == 5)
                   {
                       gotbingo = true;
                   }
       }
       // check for columns


      
       for(int col = 0; col < 5; col++)
       {
           count = 0;
           for(int row = 0; row < 5; row++)
           {
               if(bingoCardArray[row][col] == 0)
               {
                   count++;
                  
               }


               if(count == 5)
                   {
                       gotbingo = true;
                   }
           }
       }


       //check for diagonal from top-left to bottom-right
       count = 0;
       for(int i = 0; i < 5; i++)
       {
           if(bingoCardArray[i][i] == 0)
           {
               count++;
           }
           if(count == 5)
               {
                   gotbingo = true;
               }
   
       }
       

       //check diagonal from top-right to bottom-left


       count = 0;
       for(int i = 0; i < 5; i++)
       {
           if(bingoCardArray[i][4-i] == 0)
           {
               count++;
                 
           }


           if(count == 5)
               {
                   gotbingo = true;
               }
       }
       return gotbingo;
   }
  
  
   public String toString()
   {
       //return a string that contains the entire Bingo Card, including the
        //headers of B I N G O and all the rows below it.


        String BingoCard = "B I N G O\n";
        for(int row = 0; row < 5; row++)
        {
            for(int col = 0; col < 5; col++)
            {
                BingoCard+= bingoCardArray[row][col] + " ";
                if(col == 4)
                {
                    BingoCard+= "\n";
                }
            }
        }
       return BingoCard;
   }
  
}
